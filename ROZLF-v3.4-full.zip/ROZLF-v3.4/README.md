# ROZLF v3.4 — تحليل فوركس وذهب ببيانات حقيقية

تطبيق فوركس عربي/إنجليزي بواجهة iPhone داكنة (PWA + iOS). **مجاني بالكامل**: بلا Premium، بلا اشتراكات، بلا حسابات، وبلا أقسام مقفلة.

## ما الجديد في 3.4

- **أسعار مباشرة من Swissquote** لكل الأزواج الـ11 + الذهب، مع bid/ask/spread ووقت آخر تحديث ووسم LIVE فقط عند نجاح المصدر.
- **شموع OHLC حقيقية** لكل الفريمات M5 · M15 · H1 · H4 · D1 عبر سلسلة مصادر: Kraken → Bitstamp → Twelve Data → Yahoo (عبر Jina عند الحجب).
  - GBP/JPY مُشتق رياضياً من GBP/USD × USD/JPY (موسوم `kraken-derived`).
  - XAU/USD عبر PAXG (ذهب مرجعي موسوم `paxg`)، وNZD/USD عبر Yahoo.
- **صفر بيانات وهمية**: لا `Math.random` للأسعار أو الشموع. عند فشل كل المصادر تظهر **DATA UNAVAILABLE** بدل شارت وهمي.
- **مؤشرات كاملة**: RSI, MACD + Signal + Histogram, Stochastic %K/%D, MA20/50/200, EMA, Bollinger, ATR، ودعم/مقاومة، وSMC (BOS/CHoCH/FVG/Order Blocks).
- **تحليل Gemini** نصي وصورة (PNG/JPG/WEBP مع ضغط قبل الإرسال) عبر Worker؛ وعند غياب المفتاح يعمل **تحليل محلي من البيانات الحقيقية** تلقائياً.
- **إشارات من شموع حقيقية فقط** مع المصدر والوقت، وتقييم لاحق بسعر حقيقي.
- **واجهة iPhone**: شريط سفلي بأيقونات، بطاقة سعر Hero، Cairo للعربية وIBM Plex Mono للأرقام، احترام Dynamic Island وsafe-area، ووضع عمودي فقط.
- **PWA**: manifest + Service Worker (كاش `rozlf-v3.4`) + أيقونات 180/512/SVG.

## تشغيل محلياً (بدون أي مفاتيح)

```bash
npm install                     # مرة واحدة (لتشغيل Capacitor فقط)
node scripts/dev-server.mjs     # أو: npx wrangler dev worker/index.js --port 8787
cd www && python3 -m http.server 8080
```

افتح `http://localhost:8080` — التطبيق يستخدم تلقائياً `http://localhost:8787` كـ Worker محلي.

بدون Worker: الشارت يعمل مباشرة من Bitstamp لـ EUR/USD وGBP/USD فقط، وبقية الأزواج تعرض DATA UNAVAILABLE (بصدق).

## النشر (Cloudflare) — اختياري، الإعدادات جاهزة

```bash
# 1) Worker
npx wrangler deploy worker/index.js --name rozlf-api
npx wrangler secret put GEMINI_KEY     # اختياري: لتشغيل Gemini
npx wrangler secret put TWELVE_KEY     # اختياري: شموع إضافية

# 2) الواجهة على Pages
npx wrangler pages deploy www --project-name rozlf
```

ثم ضع رابط الـ Worker في:

- `www/config.js` → `API_BASE: "https://rozlf-api.<account>.workers.dev"`، أو
- من داخل التطبيق: **المزيد ← رابط الخادم (Worker) ← حفظ**.

يمكن إضافة مفتاح Gemini من **التحليل ← GEMINI ← حفظ** في الجهاز، أو كـ Secret على الـ Worker. التطبيق يعمل كاملاً بدونه (تحليل محلي).

## بناء IPA (GitHub Actions)

الملف `.github/workflows/ios.yml` يبني IPA غير موقّع على macOS:

```bash
gh workflow run ios.yml --ref main
gh run download <run-id> -n ROZLF-unsigned-ipa
```

ثم وقّعه بـ ESign على iPhone. الإصدار الحالي: **3.4.0 (34)**، Bundle ID: `com.rozlf.app`.

## مصادر البيانات

| المصدر | الاستخدام | مفتاح |
|--------|-----------|-------|
| Swissquote public quotes | أسعار مباشرة bid/ask لكل الأزواج | لا |
| Kraken OHLC | شموع 8 أزواج + اشتقاق GBP/JPY + PAXG للذهب | لا |
| Bitstamp OHLC | شموع EUR/USD وGBP/USD (ويعمل من الجهاز مباشرة) | لا |
| Twelve Data | شموع إضافية عند وجود مفتاح | اختياري |
| Yahoo Finance + Jina | شموع NZD/USD وبديل احتياطي | لا |
| Gemini API | تحليل نصي/صورة | اختياري |
| open.er-api / gold-api / ECB | أسعار مرجعية فقط (ليست LIVE) | لا |

## ملاحظات الصدق

- السعر لا يُوسم LIVE إلا إذا نجح مصدر حقيقي في تلك اللحظة.
- التحليل تعليمي وليس نصيحة استثمارية، ولا يضمن أرباحاً ولا يخترع نسب نجاح.
- لا تُحوَّل النتائج غير المعروفة في السجل إلى فوز/خسارة.
