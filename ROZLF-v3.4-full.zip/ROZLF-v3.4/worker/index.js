/**
 * ROZLF v3.4 — Cloudflare Worker
 * Real market data (Yahoo Finance) + optional Twelve Data + Gemini analysis.
 * Routes: /prices /history /news /analyze /health
 */

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, X-Gemini-Key',
  'Access-Control-Max-Age': '86400',
};

const json = (data, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...CORS },
  });

const memo = new Map();
function cached(key, ttl, fn) {
  const hit = memo.get(key);
  if (hit && Date.now() - hit.t < ttl) return Promise.resolve(hit.v);
  return fn().then((v) => { memo.set(key, { t: Date.now(), v }); return v; });
}

const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1';

async function request(url, timeout = 9000, type = 'json') {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeout);
  try {
    const r = await fetch(url, { signal: ctrl.signal, headers: { Accept: type === 'json' ? 'application/json' : 'application/rss+xml, application/xml, text/xml', 'User-Agent': UA } });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return type === 'json' ? await r.json() : await r.text();
  } finally { clearTimeout(timer); }
}

async function getJSON(url, timeout = 9000) { return request(url, timeout, 'json'); }

let yahooChain = Promise.resolve();
let yahooLast = 0;

function yahooChart(symbol, interval, range) {
  const q = '/v8/finance/chart/' + encodeURIComponent(symbol) + '?interval=' + interval + '&range=' + range;
  const hosts = ['https://query1.finance.yahoo.com', 'https://query2.finance.yahoo.com'];
  const task = yahooChain.then(async () => {
    let lastErr = null;
    for (let attempt = 0; attempt < 4; attempt++) {
      const wait = Math.max(0, 450 - (Date.now() - yahooLast));
      if (wait) await new Promise((r) => setTimeout(r, wait));
      yahooLast = Date.now();
      const host = hosts[attempt % hosts.length];
      try { return await getJSON(host + q); }
      catch (e) {
        lastErr = e;
        if (String(e.message).indexOf('429') === -1) break;
        await new Promise((r) => setTimeout(r, 500 + attempt * 700 + Math.floor(Math.random() * 400)));
      }
    }
    throw lastErr || new Error('yahoo unavailable');
  });
  yahooChain = task.catch(() => {});
  return task;
}

const PAIRS = {
  EURUSD: { yahoo: 'EURUSD=X', td: 'EUR/USD', dp: 5 },
  GBPUSD: { yahoo: 'GBPUSD=X', td: 'GBP/USD', dp: 5 },
  USDJPY: { yahoo: 'USDJPY=X', td: 'USD/JPY', dp: 3 },
  AUDUSD: { yahoo: 'AUDUSD=X', td: 'AUD/USD', dp: 5 },
  USDCAD: { yahoo: 'USDCAD=X', td: 'USD/CAD', dp: 5 },
  NZDUSD: { yahoo: 'NZDUSD=X', td: 'NZD/USD', dp: 5 },
  USDCHF: { yahoo: 'USDCHF=X', td: 'USD/CHF', dp: 5 },
  EURJPY: { yahoo: 'EURJPY=X', td: 'EUR/JPY', dp: 3 },
  GBPJPY: { yahoo: 'GBPJPY=X', td: 'GBP/JPY', dp: 3 },
  EURGBP: { yahoo: 'EURGBP=X', td: 'EUR/GBP', dp: 5 },
  XAUUSD: { yahoo: 'GC=F', td: 'XAU/USD', dp: 2 },
};

async function yahooQuote(pair) {
  const p = PAIRS[pair];
  if (!p) throw new Error('unsupported pair');
  const d = await yahooChart(p.yahoo, '1m', '1d');
  const res = d && d.chart && d.chart.result && d.chart.result[0];
  const meta = res && res.meta;
  if (!meta) throw new Error('no meta');
  const price = Number(meta.regularMarketPrice != null ? meta.regularMarketPrice : meta.previousClose);
  if (!isFinite(price) || price <= 0) throw new Error('bad price');
  return {
    price: +price.toFixed(p.dp),
    ts: (meta.regularMarketTime || Date.now() / 1000) * 1000,
    kind: 'yahoo',
    prevClose: Number(meta.chartPreviousClose || meta.previousClose || 0) || null,
  };
}

async function referencePrices() {
  const out = {};
  const [fx, gold] = await Promise.allSettled([
    getJSON('https://open.er-api.com/v6/latest/USD'),
    getJSON('https://api.gold-api.com/price/XAU'),
  ]);
  let rates = null, ts = 0;
  if (fx.status === 'fulfilled' && fx.value && fx.value.rates) {
    rates = fx.value.rates;
    ts = (fx.value.time_last_update_unix || 0) * 1000 || Date.now();
  } else {
    const f = await getJSON('https://api.frankfurter.app/latest?from=USD&to=EUR,GBP,JPY,AUD,CAD,CHF,NZD');
    rates = f.rates; ts = Date.parse(f.date + 'T16:00:00Z') || Date.now();
  }
  if (!rates) throw new Error('no fx rates');
  if (rates.EUR) out.EURUSD = { price: +(1 / rates.EUR).toFixed(5), ts, kind: 'ecb' };
  if (rates.GBP) out.GBPUSD = { price: +(1 / rates.GBP).toFixed(5), ts, kind: 'ecb' };
  if (rates.JPY) out.USDJPY = { price: +rates.JPY.toFixed(3), ts, kind: 'ecb' };
  if (rates.AUD) out.AUDUSD = { price: +(1 / rates.AUD).toFixed(5), ts, kind: 'ecb' };
  if (rates.CAD) out.USDCAD = { price: +rates.CAD.toFixed(5), ts, kind: 'ecb' };
  if (rates.CHF) out.USDCHF = { price: +rates.CHF.toFixed(5), ts, kind: 'ecb' };
  if (rates.NZD) out.NZDUSD = { price: +(1 / rates.NZD).toFixed(5), ts, kind: 'ecb' };
  if (gold.status === 'fulfilled' && gold.value && Number(gold.value.price) > 0) {
    out.XAUUSD = {
      price: +Number(gold.value.price).toFixed(2),
      ts: gold.value.updatedAt ? Date.parse(gold.value.updatedAt) : Date.now(),
      kind: 'goldapi',
    };
  }
  return out;
}

async function swissQuote(pair) {
  const p = PAIRS[pair];
  const sym = p.td || pair.replace(/(\w{3})(\w{3})/, '$1/$2');
  const d = await getJSON('https://forex-data-feed.swissquote.com/public-quotes/bboquotes/instrument/' + sym);
  if (!Array.isArray(d) || !d.length) throw new Error('no swissquote data');
  const row = d[0];
  const prof = (row.spreadProfilePrices && row.spreadProfilePrices[0]) || null;
  if (!prof || !Number.isFinite(prof.bid) || !Number.isFinite(prof.ask)) throw new Error('bad swissquote quote');
  const mid = (prof.bid + prof.ask) / 2;
  return { price: +mid.toFixed(p.dp), ts: row.ts || Date.now(), kind: 'swissquote', bid: prof.bid, ask: prof.ask };
}

async function spotPrices() {
  const out = {};
  const keys = Object.keys(PAIRS);
  const results = await Promise.allSettled(keys.map((k) => swissQuote(k)));
  results.forEach((r, i) => { if (r.status === 'fulfilled') out[keys[i]] = r.value; });
  if (Object.keys(out).length < keys.length) {
    try {
      const ref = await referencePrices();
      for (const k of Object.keys(ref)) if (!out[k]) out[k] = ref[k];
    } catch (e) { /* keep live subset */ }
  }
  if (!Object.keys(out).length) throw new Error('no price source available');
  return out;
}

const TF_MAP = {
  M5: ['5m', '10d'], M15: ['15m', '1mo'], M30: ['30m', '1mo'],
  H1: ['1h', '3mo'], H4: ['1h', '6mo'], D1: ['1d', '2y'],
};

function resampleH4(candles) {
  const buckets = new Map();
  for (const c of candles) {
    const d = new Date(c.t);
    const key = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate(), Math.floor(d.getUTCHours() / 4) * 4);
    let b = buckets.get(key);
    if (!b) { b = { t: key, o: c.o, h: c.h, l: c.l, c: c.c, v: c.v || 0 }; buckets.set(key, b); }
    else { b.h = Math.max(b.h, c.h); b.l = Math.min(b.l, c.l); b.c = c.c; b.v += c.v || 0; }
  }
  return Array.from(buckets.keys()).sort((a, b) => a - b).map((k) => buckets.get(k));
}

async function twelveCandles(pair, tf, key) {
  const p = PAIRS[pair];
  if (!p || !p.td) throw new Error('unsupported');
  const map = { M5: '5min', M15: '15min', M30: '30min', H1: '1h', H4: '4h', D1: '1day' };
  const interval = map[tf] || '15min';
  const d = await getJSON('https://api.twelvedata.com/time_series?symbol=' + encodeURIComponent(p.td) +
    '&interval=' + interval + '&outputsize=300&timezone=UTC&apikey=' + encodeURIComponent(key));
  if (!d || d.status === 'error' || !Array.isArray(d.values)) throw new Error((d && d.message) || 'twelvedata error');
  return d.values.map((v) => ({
    t: Date.parse(String(v.datetime).replace(' ', 'T') + 'Z') || Date.now(),
    o: +v.open, h: +v.high, l: +v.low, c: +v.close, v: +(v.volume || 0),
  })).filter((c) => [c.t, c.o, c.h, c.l, c.c].every(Number.isFinite)).reverse();
}

const KR = {
  EURUSD: 'ZEURZUSD', GBPUSD: 'ZGBPZUSD', USDJPY: 'ZUSDZJPY', AUDUSD: 'AUDUSD',
  USDCAD: 'ZUSDZCAD', USDCHF: 'USDCHF', EURJPY: 'EURJPY', EURGBP: 'EURGBP'
};
const KR_INT = { M5: 5, M15: 15, M30: 30, H1: 60, H4: 240, D1: 1440 };

async function jinaChart(symbol, interval, range) {
  const u = 'https://query1.finance.yahoo.com/v8/finance/chart/' + encodeURIComponent(symbol) + '?range=' + range + '&interval=' + interval;
  const r = await request('https://r.jina.ai/' + u, 15000, 'text');
  const txt = typeof r === 'string' ? r : '';
  const i = txt.indexOf('{"chart"');
  if (i < 0) throw new Error('jina no data');
  return JSON.parse(txt.slice(i));
}

async function krakenRaw(sym, tf) {
  const itv = KR_INT[tf];
  const d = await getJSON('https://api.kraken.com/0/public/OHLC?pair=' + sym + '&interval=' + itv);
  if (!d || (d.error && d.error.length)) throw new Error('kraken ' + (d && d.error && d.error[0]));
  const key = Object.keys(d.result || {}).find((k) => k !== 'last');
  const rows = key && d.result[key];
  if (!Array.isArray(rows) || rows.length < 20) throw new Error('kraken no data');
  return rows.map((r) => ({ t: +r[0] * 1000, o: +r[1], h: +r[2], l: +r[3], c: +r[4], v: +r[6] }));
}

async function krakenCandles(pair, tf) {
  if (pair === 'XAUUSD') return krakenRaw('PAXGUSD', tf);
  if (pair === 'GBPJPY') {
    const [a, b] = await Promise.all([krakenRaw('ZGBPZUSD', tf), krakenRaw('ZUSDZJPY', tf)]);
    const n = Math.min(a.length, b.length), out = [];
    for (let i = 1; i <= n; i++) {
      const x = a[a.length - i], y = b[b.length - i];
      const ps = [x.o * y.o, x.h * y.h, x.l * y.l, x.c * y.c];
      out.unshift({ t: x.t, o: +ps[0].toFixed(3), h: +Math.max(...ps).toFixed(3), l: +Math.min(...ps).toFixed(3), c: +ps[3].toFixed(3), v: x.v });
    }
    if (out.length < 20) throw new Error('kraken derived no data');
    return out;
  }
  const sym = KR[pair];
  if (!sym) throw new Error('unsupported');
  return krakenRaw(sym, tf);
}

const BST = { EURUSD: 'eurusd', GBPUSD: 'gbpusd' };
const BST_STEP = { M5: 300, M15: 900, M30: 1800, H1: 3600, H4: 14400, D1: 86400 };

async function bitstampCandles(pair, tf) {
  const sym = BST[pair];
  if (!sym) throw new Error('unsupported');
  const step = BST_STEP[tf];
  if (!step) throw new Error('bad timeframe');
  const d = await getJSON('https://www.bitstamp.net/api/v2/ohlc/' + sym + '/?step=' + step + '&limit=300');
  const arr = d && d.data && d.data.ohlc;
  if (!Array.isArray(arr) || arr.length < 20) throw new Error('bitstamp no data');
  return arr.map((c) => ({
    t: +c.timestamp * 1000, o: +c.open, h: +c.high, l: +c.low, c: +c.close, v: +(c.volume || 0),
  })).filter((c) => [c.t, c.o, c.h, c.l, c.c].every(Number.isFinite));
}

async function candles(pair, tf, env) {
  const cfg = TF_MAP[tf];
  const p = PAIRS[pair];
  if (!cfg || !p) throw new Error('bad pair/timeframe');
  let out = null, source = '', lastErr = null;

  if (KR[pair] || pair === 'GBPJPY' || pair === 'XAUUSD') {
    try { out = await krakenCandles(pair, tf); source = pair === 'GBPJPY' ? 'kraken-derived' : pair === 'XAUUSD' ? 'paxg' : 'kraken'; }
    catch (e) { lastErr = e; }
  }
  if (!out && BST[pair]) {
    try { out = await bitstampCandles(pair, tf); source = 'bitstamp'; }
    catch (e) { lastErr = e; }
  }
  if (!out) {
    const key = (env && (env.TWELVE_KEY || env.TWELVE_API_KEY)) || 'demo';
    try { out = await twelveCandles(pair, tf, key); source = 'twelvedata'; }
    catch (e) { lastErr = e; }
  }
  if (!out) {
    const parse = (d) => {
      const res = d && d.chart && d.chart.result && d.chart.result[0];
      const q = res && res.indicators && res.indicators.quote && res.indicators.quote[0];
      if (!q) throw new Error((d && d.chart && d.chart.error && d.chart.error.description) || 'no yahoo data');
      const ts = res.timestamp || [], list = [];
      for (let i = 0; i < ts.length; i++) {
        const o = q.open[i], h = q.high[i], l = q.low[i], c = q.close[i];
        if (![o, h, l, c].every((x) => Number.isFinite(x))) continue;
        list.push({ t: ts[i] * 1000, o: +o, h: +h, l: +l, c: +c, v: +(q.volume ? q.volume[i] || 0 : 0) });
      }
      if (list.length < 20) throw new Error('too few candles');
      return tf === 'H4' ? resampleH4(list) : list;
    };
    try { out = parse(await yahooChart(p.yahoo, cfg[0], cfg[1])); source = 'yahoo'; }
    catch (e) {
      lastErr = e;
      try { out = parse(await jinaChart(p.yahoo, cfg[0], cfg[1])); source = 'yahoo'; }
      catch (e2) { lastErr = e2; }
    }
  }
  if (!out || !out.length) throw lastErr || new Error('no data');
  return { candles: out.slice(-300), source, tf, pair };
}

async function yahooNews(pair) {
  const sym = PAIRS[pair] ? PAIRS[pair].yahoo : 'EURUSD=X';
  const rss = 'https://feeds.finance.yahoo.com/rss/2.0/headline?s=' + encodeURIComponent(sym) + '&region=US&lang=en-US';
  let xml = '';
  try { xml = await request(rss, 9000, 'text'); } catch (e) { xml = ''; }
  const items = [];
  const blocks = xml.split(/<item>/i).slice(1);
  for (const b of blocks) {
    const pick = (tag) => {
      const m = new RegExp('<' + tag + '>(?:<!\\[CDATA\\[)?([\\s\\S]*?)(?:\\]\\]>)?</' + tag + '>', 'i').exec(b);
      return m ? m[1].replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'").trim() : '';
    };
    const title = pick('title'), link = pick('link'), date = pick('pubDate'), desc = pick('description');
    if (title && link) items.push({ title, link, date: Date.parse(date) || 0, desc: desc.slice(0, 220) });
    if (items.length >= 12) break;
  }
  if (!items.length) {
    const md = await request('https://r.jina.ai/' + rss, 14000, 'text');
    const re = /^###\s*\[([^\]]+)\]\((https?:[^)\s]+)\)/gm;
    let m;
    while ((m = re.exec(md)) && items.length < 12) items.push({ title: m[1].trim(), link: m[2], date: 0, desc: '' });
  }
  return items;
}

const MODELS = ['gemini-2.5-flash', 'gemini-2.5-flash-lite', 'gemini-2.0-flash', 'gemini-1.5-flash'];

async function gemini(key, prompt, image) {
  const parts = image && image.data
    ? [{ text: prompt }, { inline_data: { mime_type: image.mime, data: image.data } }]
    : [{ text: prompt }];
  let lastErr = '';
  for (const model of MODELS) {
    try {
      const r = await fetch('https://generativelanguage.googleapis.com/v1beta/models/' + model + ':generateContent?key=' + encodeURIComponent(key), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ role: 'user', parts }],
          generationConfig: { temperature: 0.3, maxOutputTokens: 2200, topP: 0.9 },
          safetySettings: [],
        }),
      });
      const d = await r.json().catch(() => null);
      if (!r.ok) {
        const msg = (d && d.error && d.error.message) || 'HTTP ' + r.status;
        lastErr = msg;
        if (r.status === 400 || r.status === 403) break;
        continue;
      }
      const cand = d && d.candidates && d.candidates[0];
      const text = cand && cand.content && cand.content.parts ? cand.content.parts.map((p) => p.text || '').join('') : '';
      if (text) return { text, model };
      lastErr = 'empty response';
    } catch (e) { lastErr = e.message; }
  }
  throw new Error(lastErr || 'gemini failed');
}

const MIME_OK = ['image/png', 'image/jpeg', 'image/webp'];

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
    const t0 = Date.now();

    if (url.pathname === '/prices') {
      try {
        const prices = await cached('prices', 12000, spotPrices);
        const kinds = Object.values(prices).map((p) => p.kind);
        return json({
          ok: true, prices, t: Date.now(),
          source: kinds.every((k) => k === 'swissquote') ? 'swissquote' : kinds.some((k) => k === 'swissquote') ? 'swissquote+ref' : kinds.every((k) => k === 'yahoo') ? 'yahoo' : 'reference',
          live: kinds.filter((k) => k === 'swissquote' || k === 'yahoo').length,
          count: Object.keys(prices).length,
        });
      } catch (e) { return json({ ok: false, error: e.message }, 502); }
    }

    if (url.pathname === '/history') {
      const pair = (url.searchParams.get('pair') || 'EURUSD').replace(/-OTC|-Smarty/gi, '').toUpperCase();
      const tf = (url.searchParams.get('tf') || 'M15').toUpperCase();
      if (!PAIRS[pair]) return json({ ok: false, error: 'unsupported pair', pair }, 400);
      if (!TF_MAP[tf]) return json({ ok: false, error: 'unsupported timeframe', tf }, 400);
      try {
        const r = await cached('h:' + pair + tf, 120000, () => candles(pair, tf, env));
        return json({
          ok: true, pair, tf, candles: r.candles, source: r.source,
          last: r.candles[r.candles.length - 1].c,
          lastTime: r.candles[r.candles.length - 1].t,
          t: Date.now(), ms: Date.now() - t0,
        });
      } catch (e) { return json({ ok: false, error: e.message, pair, tf }, 502); }
    }

    if (url.pathname === '/news') {
      const pair = (url.searchParams.get('pair') || 'EURUSD').replace(/-OTC|-Smarty/gi, '').toUpperCase();
      try {
        const items = await cached('news:' + pair, 300000, () => yahooNews(pair));
        if (!items.length) return json({ ok: false, error: 'no news available' }, 502);
        return json({ ok: true, pair, items, source: 'Yahoo Finance RSS', t: Date.now() });
      } catch (e) { return json({ ok: false, error: e.message }, 502); }
    }

    if (url.pathname === '/analyze' && request.method === 'POST') {
      try {
        const body = await request.json().catch(() => ({}));
        const pair = String(body.pair || 'EURUSD').slice(0, 20);
        const market = String(body.market || 'Forex').slice(0, 30);
        const lang = body.lang === 'en' ? 'English' : 'Arabic';
        const price = String(body.price || '');
        const tf = String(body.tf || '');
        const summary = body.summary && typeof body.summary === 'object' ? body.summary : null;
        const key = env.GEMINI_KEY || request.headers.get('X-Gemini-Key') || body.geminiKey;
        if (!key) return json({ ok: false, error: 'gemini key not configured on server', code: 'NO_KEY' }, 401);
        if (body.image && body.image.data) {
          if (!MIME_OK.includes(body.image.mime)) return json({ ok: false, error: 'unsupported image type (PNG, JPG, WEBP only)' }, 415);
          if (String(body.image.data).length > 8 * 1024 * 1024) return json({ ok: false, error: 'image too large (max ~6MB)' }, 413);
        }
        const nums = 'السعر ' + price + '، RSI ' + (body.rsi || '—') + '، MACD ' + (body.macd || '—') +
          '، Bollinger ' + (body.bb || '—') + '، Stochastic ' + (body.stoch || '—') + '، الاتجاه ' + (body.direction || 'NEUTRAL');
        const prompt = (typeof body.prompt === 'string' && body.prompt.length > 40 && body.prompt.length < 8000)
          ? body.prompt
          : 'أنت محلل فوركس ومحلل SMC محترف. الزوج ' + pair + ' في سوق ' + market +
          (tf ? ' على الإطار الزمني ' + tf : '') + '. ' + nums + '.\n' +
          (summary ? 'بيانات حقيقية إضافية (JSON): ' + JSON.stringify(summary) + '\n' : '') +
          (body.image && body.image.data ? 'حلّل صورة الشارت المرفقة أولاً (شموع، اتجاه، سيولة) ثم ادعمها بالأرقام.\n' : '') +
          'اكتب باللغة ' + lang + ' تحليلاً منظماً يغطي: الاتجاه، السيولة، BOS/CHoCH، FVG، Order Blocks، الدعم والمقاومة.\n' +
          'في النهاية اكتب حرفياً:\nVERDICT: BUY أو SELL أو NO TRADE\nENTRY: ...\nSTOP: ...\nTARGET1: ...\nTARGET2: ...\nREASON: 3-5 أسطر\n' +
          'استخدم فقط الأرقام المتاحة. إذا كانت البيانات غير كافية اكتب NO TRADE ولا تخترع أسعاراً. لا تضمن أرباحاً ولا تخترع نسبة نجاح أو ثقة.';
        const out = await gemini(key, prompt, body.image);
        return json({ ok: true, analysis: out.text, model: out.model, t: Date.now() });
      } catch (e) { return json({ ok: false, error: e.message }, 500); }
    }

    if (url.pathname === '/health') {
      return json({ ok: true, version: '3.4', gemini: !!env.GEMINI_KEY, twelve: !!(env.TWELVE_KEY || env.TWELVE_API_KEY), t: Date.now() });
    }

    return json({ ok: false, error: 'Not found' }, 404);
  },
};
