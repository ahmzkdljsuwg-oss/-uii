import { cp, rm, readdir } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import path from 'node:path';

const src = path.resolve('www');
const dst = path.resolve('ios/App/App/public');

if (!existsSync(src)) { console.error('www/ not found'); process.exit(1); }
await rm(dst, { recursive: true, force: true });
await cp(src, dst, { recursive: true });
const n = (await readdir(dst)).length;
console.log(`synced ${n} files -> ${dst}`);
