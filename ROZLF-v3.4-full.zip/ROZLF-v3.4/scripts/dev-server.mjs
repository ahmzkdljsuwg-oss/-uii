import http from 'node:http';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const www = path.join(root, 'www');
const WORKER_PORT = Number(process.env.WORKER_PORT || 8787);
const WEB_PORT = Number(process.env.WEB_PORT || 8080);

const worker = (await import(path.join(root, 'worker/index.js'))).default;

const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };

const api = http.createServer(async (req, res) => {
  try {
    const chunks = [];
    for await (const c of req) chunks.push(c);
    const body = chunks.length ? Buffer.concat(chunks) : undefined;
    const url = new URL(req.url, `http://127.0.0.1:${WORKER_PORT}`);
    const r = await worker.fetch(new Request(url, {
      method: req.method, headers: req.headers, body: req.method === 'GET' || req.method === 'HEAD' ? undefined : body,
    }), {}, { waitUntil() {}, passThroughOnException() {} });
    res.writeHead(r.status, Object.fromEntries(r.headers));
    res.end(Buffer.from(await r.arrayBuffer()));
  } catch (e) {
    res.writeHead(502, { 'content-type': 'application/json', 'access-control-allow-origin': '*' });
    res.end(JSON.stringify({ ok: false, error: String(e && e.message || e) }));
  }
});

const web = http.createServer(async (req, res) => {
  try {
    const p = decodeURIComponent(new URL(req.url, 'http://x').pathname);
    const file = path.join(www, p === '/' ? 'index.html' : p);
    if (!file.startsWith(www)) { res.writeHead(403); return res.end(); }
    const data = await readFile(file);
    res.writeHead(200, { 'content-type': TYPES[path.extname(file)] || 'application/octet-stream', 'cache-control': 'no-store' });
    res.end(data);
  } catch {
    res.writeHead(404); res.end('not found');
  }
});

api.listen(WORKER_PORT, () => console.log(`ROZLF worker API  http://localhost:${WORKER_PORT}`));
web.listen(WEB_PORT, () => console.log(`ROZLF web (PWA)   http://localhost:${WEB_PORT}`));
