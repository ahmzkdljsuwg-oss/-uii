#!/usr/bin/env bash
# Local macOS build (unsigned). Produces ROZLF-unsigned.ipa for ESign/AltStore sideloading.
set -euo pipefail
cd "$(dirname "$0")/.."
npm ci
npx cap sync ios
cd ios/App
xcodebuild -workspace App.xcworkspace -scheme App -configuration Release \
  -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath ../../build \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" DEVELOPMENT_TEAM="" \
  ARCHS=arm64 ONLY_ACTIVE_ARCH=NO build
cd ../..
APP="build/Build/Products/Release-iphoneos/App.app"
rm -rf Payload ROZLF-unsigned.ipa && mkdir Payload && cp -R "$APP" Payload/
zip -qry ROZLF-unsigned.ipa Payload
echo "Built: $(pwd)/ROZLF-unsigned.ipa"
